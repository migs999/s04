
db.getCollection('employees').find({})
/* 1 */
{
    "_id" : 312456.0,
    "empName" : "Barry Stevens",
    "empAge" : 28.0,
    "jobRole" : "Store Manager",
    "salary" : 120000.0
}

/* 2 */
{
    "_id" : 3245624.0,
    "empName" : "Barrys Stevenss",
    "empAge" : 28.0,
    "jobRole" : "Store Manager",
    "salary" : 1200030.0
}

/* 3 */
{
    "_id" : 312986456.0,
    "empName" : "kim Stevens",
    "empAge" : 28.0,
    "jobRole" : "Store Manager",
    "salary" : 120000.0
}

/* 4 */
{
    "_id" : 3126321456.0,
    "empName" : "lore Stevens",
    "empAge" : 28.0,
    "jobRole" : "Store Manager",
    "salary" : 120000.0
}

/* 5 */
{
    "_id" : 31243356.0,
    "empName" : "jackob Stevens",
    "empAge" : 28.0,
    "jobRole" : "Store Manager",
    "salary" : 120000.0
}

/* 6 */
{
    "_id" : 312325325456.0,
    "empName" : "Barry allen",
    "empAge" : 28.0,
    "jobRole" : "Store Manager",
    "salary" : 325235325235.0
}



db.getCollection('inventory').find({})

/* 1 */
{
    "_id" : 1,
    "itemname" : "apple",
    "amount" : 2.0
}

/* 2 */
{
    "_id" : 2,
    "itemname" : "orange",
    "amount" : 2.0
}

/* 3 */
{
    "_id" : 3,
    "itemname" : "pear",
    "amount" : 34
}

/* 4 */
{
    "_id" : 4,
    "itemname" : "peaches",
    "amount" : 3
}

/* 5 */
{
    "_id" : 5,
    "itemname" : "lime",
    "amount" : 433
}

/* 6 */
{
    "_id" : 6,
    "itemname" : "grapes",
    "amount" : 1
}


db.getCollection('items').find({})